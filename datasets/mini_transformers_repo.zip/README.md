# Miniformer
A minimal, educational library for building transformer blocks, designed for agent-based code generation tasks.
This library provides core components for building and experimenting with transformer architectures.