import torch
import torch.nn.functional as F
from scipy.special import erf
import numpy as np

def gelu_exact(x):
    """Gaussian Error Linear Unit (GELU) activation function using SciPy's erf for NumPy arrays."""
    return 0.5 * x * (1.0 + erf(x / np.sqrt(2.0)))

def get_activation(name: str):
    """Returns the activation function corresponding to the name."""
    if name == 'relu':
        return F.relu
    elif name == 'gelu':
        return F.gelu # PyTorch's optimized GELU for tensors
    else:
        raise ValueError(f"Unknown activation function: {name}")