from pydantic import BaseModel, Field
from typing import Literal

class TransformerConfig(BaseModel):
    """Configuration for a Miniformer model."""
    vocab_size: int = Field(default=1000, ge=1)
    n_layer: int = Field(default=4, ge=1)
    n_head: int = Field(default=4, ge=1)
    n_embd: int = Field(default=128, ge=1)
    block_size: int = Field(default=256, ge=1)
    attn_pdrop: float = Field(default=0.1, ge=0.0, le=1.0)
    resid_pdrop: float = Field(default=0.1, ge=0.0, le=1.0)
    activation_function: Literal['relu', 'gelu'] = 'gelu'

    class Config:
        validate_assignment = True

    def __post_init__(self):
        if self.n_embd % self.n_head != 0:
            raise ValueError("n_embd must be divisible by n_head")