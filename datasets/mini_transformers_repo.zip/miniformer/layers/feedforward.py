import torch.nn as nn
from miniformer.activations import get_activation

class FeedForward(nn.Module):
    """A position-wise feed-forward network."""
    def __init__(self, config):
        super().__init__()
        self.c_fc    = nn.Linear(config.n_embd, 4 * config.n_embd)
        self.c_proj  = nn.Linear(4 * config.n_embd, config.n_embd)
        self.dropout = nn.Dropout(config.resid_pdrop)
        self.activation = get_activation(config.activation_function)

    def forward(self, x):
        return self.dropout(self.c_proj(self.activation(self.c_fc(x))))