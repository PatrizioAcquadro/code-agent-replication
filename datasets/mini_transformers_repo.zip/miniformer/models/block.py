import torch.nn as nn
from miniformer.layers.attention import MultiHeadSelfAttention
from miniformer.layers.feedforward import FeedForward

class TransformerBlock(nn.Module):
    """
    A single block of a transformer model. It consists of a multi-head
    self-attention layer followed by a feed-forward network. Layer
    normalization and residual connections are applied.
    """
    def __init__(self, config):
        super().__init__()
        self.ln_1 = nn.LayerNorm(config.n_embd)
        self.attn = MultiHeadSelfAttention(config)
        self.ln_2 = nn.LayerNorm(config.n_embd)
        self.mlp = FeedForward(config)

    def forward(self, x):
        x = x + self.attn(self.ln_1(x))
        x = x + self.mlp(self.ln_2(x))
        return x