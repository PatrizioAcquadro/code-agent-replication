import numpy as np
import math
import torch

def to_numpy(tensor):
    """Converts a PyTorch tensor to a NumPy array on the CPU."""
    if tensor is None: return None
    return tensor.detach().cpu().numpy()

def kaiming_uniform_numpy(shape, a=0, mode='fan_in', nonlinearity='leaky_relu'):
    """A simplified numpy-based Kaiming uniform initializer."""
    fan = np.prod(shape[1:]) if mode == 'fan_in' else shape[0]
    gain = math.sqrt(2.0 / (1 + a**2)) if nonlinearity == 'leaky_relu' else 1.0
    std = gain / math.sqrt(fan)
    bound = math.sqrt(3.0) * std
    return np.random.uniform(-bound, bound, size=shape)