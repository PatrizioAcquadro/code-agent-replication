import numpy as np
import time

def assert_allclose(actual, desired, rtol=1e-6, atol=1e-6, label=""):
    """A wrapper around np.testing.assert_allclose with a label for better test reporting."""
    try:
        np.testing.assert_allclose(actual, desired, rtol=rtol, atol=atol)
        if label: print(f"Assertion PASSED for: {label}")
    except AssertionError as e:
        print(f"Assertion FAILED for: {label}" if label else "Assertion FAILED.")
        raise e