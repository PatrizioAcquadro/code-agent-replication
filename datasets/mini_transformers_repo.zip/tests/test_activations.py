import pytest
import torch
from miniformer.activations import get_activation

def test_swish_activation():
    # This test is expected to fail until Task #4 is completed.
    try:
        swish = get_activation('swish')
        x = torch.tensor([1.0, 2.0, -1.0])
        expected = x * torch.sigmoid(x)
        assert torch.allclose(swish(x), expected)
    except ValueError:
        pytest.fail("Activation 'swish' is not registered in get_activation.")