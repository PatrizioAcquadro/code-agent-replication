import pytest
from miniformer.config import TransformerConfig

def test_config_instantiation():
    # Tests that a config can be created with custom values (Task #11)
    config = TransformerConfig(n_layer=2, n_head=2, n_embd=32)
    assert config.n_layer == 2
    assert config.n_head == 2
    assert config.n_embd == 32

def test_config_to_dict_method():
    # This test is expected to fail until Task #3 is completed.
    config = TransformerConfig()
    try:
        d = config.to_dict()
        assert isinstance(d, dict)
        assert d['n_embd'] == 128
    except AttributeError:
        pytest.fail("The 'to_dict' method does not exist on TransformerConfig.")

def test_config_bias_field():
    # This test is expected to fail until Task #1 is completed.
    try:
        config = TransformerConfig(use_bias=True)
        assert config.use_bias is True
    except TypeError:
        pytest.fail("The 'use_bias' field does not exist on TransformerConfig.")