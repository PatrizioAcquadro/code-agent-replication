import pytest
from miniformer.config import TransformerConfig

# This file contains tests for components that are created by agent tasks.
# These tests are EXPECTED TO FAIL until the agent completes the tasks.

def test_positional_embedding_layer():
    # This test is for Task #5.
    try:
        from miniformer.layers.embedding import PositionalEmbedding
        config = TransformerConfig(block_size=64, n_embd=32)
        layer = PositionalEmbedding(config)
        input_tensor = torch.rand(2, 16, 32) # B, T, C
        pos_emb = layer(input_tensor)
        assert pos_emb.shape == (16, 32) # T, C
    except ImportError:
        pytest.fail("File 'miniformer/layers/embedding.py' or class 'PositionalEmbedding' not found.")

def test_full_model_instantiation():
    # This test is for Task #10.
    try:
        from miniformer.models.model import Miniformer
        config = TransformerConfig()
        model = Miniformer(config)
        assert model is not None
    except ImportError:
        pytest.fail("File 'miniformer/models/model.py' or class 'Miniformer' not found.")

def test_language_model_head():
    # This test is for Task #15.
    try:
        from miniformer.models.head import LanguageModelHead
        config = TransformerConfig(n_embd=32, vocab_size=100)
        head = LanguageModelHead(config)
        input_tensor = torch.rand(2, 16, 32) # B, T, C
        logits = head(input_tensor)
        assert logits.shape == (2, 16, 100) # B, T, vocab_size
    except ImportError:
        pytest.fail("File 'miniformer/models/head.py' or class 'LanguageModelHead' not found.")