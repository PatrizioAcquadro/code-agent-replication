# ==============================================================================
# Comprehensive Integration Test Suite for the Miniformer Library
# ==============================================================================
#
# This file serves as the primary validation mechanism for the entire miniformer
# codebase. Unlike unit tests that might focus on a single function, these
# integration tests ensure that all the different components (config, layers,
# models, utils) work together as expected.
#
# This file is intentionally verbose and detailed to:
# 1. Provide a clear example of how to use the library's components.
# 2. Serve as a challenging, realistic file for a code generation agent to modify.
# 3. Create a statistical outlier in file size, mimicking real-world codebases.
#
# It imports from nearly every other module in the project.

import torch
import numpy as np
import time
import pytest # Using pytest for better test structure and fixtures

# Import all major components from the library
from miniformer.config import TransformerConfig
from miniformer.models.block import TransformerBlock
from miniformer.layers.attention import MultiHeadSelfAttention
from miniformer.layers.feedforward import FeedForward
from miniformer.activations import get_activation
from miniformer.utils.testing import assert_allclose
from miniformer.utils.tensor_ops import to_numpy

# --- Test Fixtures ---

@pytest.fixture(scope="module")
def default_config():
    """Provides a default, consistent TransformerConfig for all tests in this module."""
    return TransformerConfig(
        vocab_size=100,
        n_layer=2,
        n_head=4,
        n_embd=64,
        block_size=128,
        attn_pdrop=0.0,  # Disable dropout for deterministic tests
        resid_pdrop=0.0
    )

@pytest.fixture
def transformer_block(default_config):
    """Provides an initialized TransformerBlock instance for testing."""
    model = TransformerBlock(default_config)
    model.eval() # Set to evaluation mode to disable dropout behavior
    return model


# --- Core Functionality Tests ---

def test_block_forward_pass_shape(transformer_block, default_config):
    """
    PURPOSE: To verify that a forward pass through a TransformerBlock preserves
    the shape of the input tensor. This is the most fundamental sanity check.
    If input shape is (B, T, C), output shape must also be (B, T, C).
    """
    print("\n--- Running Test: Block Forward Pass Shape ---")
    batch_size = 4
    seq_len = 32
    input_tensor = torch.rand(batch_size, seq_len, default_config.n_embd)

    with torch.no_grad():
        output_tensor = transformer_block(input_tensor)

    assert input_tensor.shape == output_tensor.shape, \
        f"Shape mismatch: In {input_tensor.shape} vs Out {output_tensor.shape}"
    print("Shape preservation test PASSED.")


def test_attention_causality(default_config):
    """
    PURPOSE: To rigorously test the causal nature of the self-attention mechanism.
    A token at position `i` should NEVER be influenced by tokens at positions `j > i`.
    
    METHOD:
    1. Create an input tensor `input1`.
    2. Create a second tensor `input2` which is identical to `input1` initially.
    3. Modify `input2` at a future position (e.g., add noise at `t+1`).
    4. Pass both tensors through the attention layer.
    5. The output for position `t` should be IDENTICAL for both `output1` and `output2`.
    """
    print("\n--- Running Test: Attention Causality ---")
    attention_layer = MultiHeadSelfAttention(default_config).eval()
    seq_len = 16
    pos_to_check = 8 # The position we will observe

    # Create two input tensors.
    input1 = torch.randn(1, seq_len, default_config.n_embd)
    input2 = input1.clone()
    input2[:, pos_to_check + 1, :] += 10.0 # Add large noise to a future token

    with torch.no_grad():
        output1 = attention_layer(input1)
        output2 = attention_layer(input2)

    # The output up to and including `pos_to_check` should be bit-for-bit identical.
    out1_numpy = to_numpy(output1[:, :pos_to_check + 1, :])
    out2_numpy = to_numpy(output2[:, :pos_to_check + 1, :])

    assert_allclose(out1_numpy, out2_numpy, label="Causality Check")
    print("Causality test PASSED.")

def test_batch_independence(transformer_block):
    """
    PURPOSE: To ensure that computations for different items in a batch are
    completely independent of one another.
    
    METHOD:
    1. Process a full batch of size N > 1.
    2. Process the first item of that batch alone (batch size 1).
    3. The output from the single-item pass must be identical to the first slice
       of the output from the full-batch pass.
    """
    print("\n--- Running Test: Batch Independence ---")
    # Input with batch size > 1
    full_batch_input = torch.rand(4, 16, transformer_block.attn.n_embd)
    # Input with only the first element of the batch
    single_item_input = full_batch_input[0:1, :, :].clone()

    with torch.no_grad():
        full_batch_output = transformer_block(full_batch_input)
        single_item_output = transformer_block(single_item_input)

    # Compare the first item from the full batch output to the single item output
    out_full_numpy = to_numpy(full_batch_output[0:1, :, :])
    out_single_numpy = to_numpy(single_item_output)

    assert_allclose(out_full_numpy, out_single_numpy, label="Batch Independence")
    print("Batch independence test PASSED.")

# --- A placeholder for future tests ---
def test_model_training_step():
    """
    PURPOSE: This is a placeholder test. A real implementation would check if the
    model parameters are updated after a backward pass and optimizer step.
    For this benchmark, we just confirm that it runs without error.
    """
    print("\n--- Running Test: Model Training Step (Placeholder) ---")
    assert True
    print("Training step placeholder test PASSED.")

# --- Main execution block to run tests if the file is executed directly ---

def run_all_tests():
    """Main function to run all defined tests sequentially."""
    # This function is more for direct execution than for pytest
    config = default_config()
    block = transformer_block(config)

    test_block_forward_pass_shape(block, config)
    test_attention_causality(config)
    test_batch_independence(block)
    test_model_training_step()


if __name__ == "__main__":
    print("=============================================")
    print("    RUNNING MINIFORMER INTEGRATION SUITE     ")
    print("=============================================")
    start_time = time.time()
    
    # Manually run tests if not using pytest
    run_all_tests()
    
    end_time = time.time()
    print("\n=============================================")
    print(f"   SUITE FINISHED in {end_time - start_time:.2f}s")
    print("=============================================")