import pytest
from miniformer.config import TransformerConfig
from miniformer.models.block import TransformerBlock

def test_block_summary_method():
    # This test is expected to fail until Task #9 is completed.
    config = TransformerConfig()
    block = TransformerBlock(config)
    try:
        # Check if the method exists and returns a string containing layer names
        summary_str = block.summary()
        assert isinstance(summary_str, str)
        assert "MultiHeadSelfAttention" in summary_str
        assert "FeedForward" in summary_str
    except (AttributeError, TypeError):
        pytest.fail("The 'summary' method does not exist or does not return a string.")