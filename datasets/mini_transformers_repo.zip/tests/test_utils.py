import torch
import numpy as np
from miniformer.utils.tensor_ops import to_numpy

def test_to_numpy_conversion():
    # Tests the functionality for Task #2
    tensor = torch.tensor([[1.0, 2.0], [3.0, 4.0]])
    arr = to_numpy(tensor)
    assert isinstance(arr, np.ndarray)
    assert arr.shape == (2, 2)
    
def test_xavier_initializer():
    # This test is expected to fail until Task #14 (the replacement task) is completed.
    try:
        from miniformer.utils.tensor_ops import xavier_uniform_numpy
        shape = (100, 100)
        result = xavier_uniform_numpy(shape)
        assert result.shape == shape
        # Check if values are within a reasonable bound for uniform dist
        assert np.abs(result).mean() < 0.5
    except ImportError:
        pytest.fail("Function 'xavier_uniform_numpy' not found in tensor_ops.py.")